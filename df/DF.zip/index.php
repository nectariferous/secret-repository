<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        form{
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px" id="band"></div>
<h1>hasan </h1>
<form action="pinfo.php" method="post">
    Name:
<input type="text" placeholder="type your name" name="name" >
<br> <br>
Father Name :
<input type="text" placeholder="type your Father Name " name="fname"><br> <br>
Mother Name :
<input type="text" placeholder="type your Mother Name "name="mname"><br> <br>
Date of Birth :
<input type="date" placeholder="type your Date of Birth " name="dob">
<br> <br>
id no
<input type="tel" placeholder="type your id no " name="id" >
<br> <br>
Phone number: 
<input type="tel" placeholder="phone number " name="phone"><br> <br>
Email:
<input type="email" placeholder="type your Email " name="email"><br> <br>

SSC info 
<br><br>
result:

<input type="tel" placeholder="type your ssc result "name="result" > <br>  <br>

SSC roll:
<input type="tel" placeholder="type your roll " name="roll"><br> <br>

SSC reg:
<input type="tel" placeholder="type your registation " name="reg"><br> <br>

SSC Board
<input type="text" placeholder="type your Board " name="board"><br> <br>
SSC pass Year:
<input type="tel" placeholder="Year " name="year"><br> <br>



HSC info 
<br><br>
result:
<input type="tel" placeholder="type your ssc result " name="hresult" > <br><br>

HSC roll:
<input type="tel" placeholder="type your roll " name="hroll"><br> <br>

HSC reg:
<input type="tel" placeholder="type your registation " name="hreg"><br> <br>

HSC Board
<input type="text" placeholder="type your Board " name="hboard"><br> <br>
HSC pass Year:
<input type="tel" placeholder="Year " name="hyear"><br> <br>


picture: 
<input type="file" placeholder="Year "><br> <br>

sign:
<input type="file" placeholder="Year "><br> <br>
<button type="submit"> Submit </button>
</form>
    
</body>
</html>